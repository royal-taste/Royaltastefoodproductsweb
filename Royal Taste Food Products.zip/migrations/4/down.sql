
DROP TABLE admin_sessions;
