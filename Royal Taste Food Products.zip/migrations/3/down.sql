
DROP TABLE admin_users;
