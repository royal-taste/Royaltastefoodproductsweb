
DROP TABLE contact_submissions;
