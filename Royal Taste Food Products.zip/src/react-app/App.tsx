import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from '@getmocha/users-service/react';
import Navbar from "@/react-app/components/Navbar";
import Footer from "@/react-app/components/Footer";
import ScrollToTop from "@/react-app/components/ScrollToTop";
import { CartProvider } from "@/react-app/contexts/CartContext";
import HomePage from "@/react-app/pages/Home";
import AboutPage from "@/react-app/pages/About";
import ProductsPage from "@/react-app/pages/Products";
import ContactPage from "@/react-app/pages/Contact";
import CartPage from "@/react-app/pages/Cart";
import LoginPage from "@/react-app/pages/Login";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import AccountPage from "@/react-app/pages/Account";
import AdminPage from "@/react-app/pages/Admin";
import AdminLoginPage from "@/react-app/pages/AdminLogin";

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Router>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/products" element={<ProductsPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/auth/callback" element={<AuthCallbackPage />} />
                <Route path="/account" element={<AccountPage />} />
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/admin-login" element={<AdminLoginPage />} />
              </Routes>
            </main>
            <Footer />
            <ScrollToTop />
          </div>
        </Router>
      </CartProvider>
    </AuthProvider>
  );
}
