import { useState, useEffect } from 'react';

interface AdminUser {
  id: number;
  username: string;
  type: 'admin';
}

export function useAdminAuth() {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAdminAuth();
  }, []);

  const checkAdminAuth = async () => {
    try {
      const response = await fetch('/api/admin/me');
      const result = await response.json();

      if (result.success) {
        setAdmin(result.data);
      } else {
        setAdmin(null);
      }
    } catch (error) {
      console.error('Admin auth check error:', error);
      setAdmin(null);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      setAdmin(null);
    } catch (error) {
      console.error('Admin logout error:', error);
    }
  };

  const login = async (username: string, password: string) => {
    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const result = await response.json();

    if (result.success) {
      setAdmin(result.data);
      return { success: true };
    } else {
      return { success: false, message: result.message };
    }
  };

  return {
    admin,
    isLoading,
    login,
    logout,
    checkAdminAuth
  };
}
