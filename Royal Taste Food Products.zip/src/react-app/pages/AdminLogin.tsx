import { Link } from 'react-router';
import { Crown, Shield, ArrowRight } from 'lucide-react';

export default function AdminLoginPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center px-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-amber-700 to-orange-600 rounded-xl flex items-center justify-center">
              <Crown className="w-9 h-9 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Royal Taste</h1>
              <p className="text-sm text-gray-500 -mt-1">Food Products</p>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Choose Your Login Method</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Access your account based on your role. Admins use traditional login for inventory management, 
            while customers enjoy seamless Google authentication.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Admin Login Card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-amber-100 hover:shadow-2xl transition-all duration-300 group">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-slate-700 to-slate-900 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Admin Access</h3>
              <p className="text-gray-600 mb-8">
                Manage inventory, update prices, view orders, and access the complete admin dashboard.
              </p>
              <div className="space-y-4 mb-8">
                <div className="bg-slate-50 rounded-lg p-4 text-left">
                  <h4 className="font-semibold text-slate-800 mb-2">Features Include:</h4>
                  <ul className="text-sm text-slate-600 space-y-1">
                    <li>• Product inventory management</li>
                    <li>• Price and stock updates</li>
                    <li>• Order tracking and analytics</li>
                    <li>• Customer inquiries management</li>
                  </ul>
                </div>
              </div>
              <Link
                to="/admin"
                className="w-full bg-gradient-to-r from-slate-700 to-slate-900 text-white py-4 rounded-lg hover:from-slate-800 hover:to-slate-950 transition-all duration-300 flex items-center justify-center gap-2 font-medium group-hover:scale-105"
              >
                Admin Sign In
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Customer Login Card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-amber-100 hover:shadow-2xl transition-all duration-300 group">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-amber-700 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Customer Login</h3>
              <p className="text-gray-600 mb-8">
                Sign in with Google to access your account, manage orders, and enjoy personalized shopping.
              </p>
              <div className="space-y-4 mb-8">
                <div className="bg-amber-50 rounded-lg p-4 text-left">
                  <h4 className="font-semibold text-amber-800 mb-2">Customer Benefits:</h4>
                  <ul className="text-sm text-amber-700 space-y-1">
                    <li>• Quick Google authentication</li>
                    <li>• Order history and tracking</li>
                    <li>• Personalized recommendations</li>
                    <li>• Secure account management</li>
                  </ul>
                </div>
              </div>
              <Link
                to="/login"
                className="w-full bg-gradient-to-r from-amber-700 to-orange-600 text-white py-4 rounded-lg hover:from-amber-800 hover:to-orange-700 transition-all duration-300 flex items-center justify-center gap-2 font-medium group-hover:scale-105"
              >
                Customer Sign In
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link 
            to="/"
            className="text-amber-700 hover:text-amber-800 font-medium transition-colors flex items-center justify-center gap-2"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
