import { useEffect, useState } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { Crown, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { Link } from 'react-router';

export default function AuthCallback() {
  const { exchangeCodeForSessionToken } = useAuth();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const handleAuth = async () => {
      try {
        await exchangeCodeForSessionToken();
        setStatus('success');
        setMessage('Successfully signed in! Redirecting...');
        
        // Redirect to home after 2 seconds
        setTimeout(() => {
          window.location.href = '/';
        }, 2000);
      } catch (error) {
        console.error('Auth callback error:', error);
        setStatus('error');
        setMessage('Authentication failed. Please try again.');
      }
    };

    handleAuth();
  }, [exchangeCodeForSessionToken]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-amber-100 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-amber-700 to-orange-600 rounded-lg flex items-center justify-center">
              <Crown className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Royal Taste</h1>
              <p className="text-xs text-gray-500 -mt-1">Food Products</p>
            </div>
          </div>

          {status === 'loading' && (
            <div>
              <Loader2 className="w-12 h-12 animate-spin text-amber-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-800 mb-2">Completing Sign In</h2>
              <p className="text-gray-600">Please wait while we set up your account...</p>
            </div>
          )}

          {status === 'success' && (
            <div>
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-800 mb-2">Welcome!</h2>
              <p className="text-gray-600">{message}</p>
            </div>
          )}

          {status === 'error' && (
            <div>
              <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-800 mb-2">Authentication Error</h2>
              <p className="text-gray-600 mb-6">{message}</p>
              <div className="space-y-3">
                <Link 
                  to="/login"
                  className="block w-full bg-gradient-to-r from-amber-700 to-orange-600 text-white py-3 rounded-lg hover:from-amber-800 hover:to-orange-700 transition-all duration-300 font-medium"
                >
                  Try Again
                </Link>
                <Link 
                  to="/"
                  className="block w-full text-amber-700 hover:text-amber-800 font-medium transition-colors"
                >
                  Return to Home
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
