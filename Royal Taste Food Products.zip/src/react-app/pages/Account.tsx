import { useAuth } from '@getmocha/users-service/react';
import { User, ShoppingBag, LogOut, Crown, Mail, Calendar } from 'lucide-react';
import { Link } from 'react-router';

export default function Account() {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <User className="w-8 h-8 text-gray-400" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Please Sign In</h1>
          <p className="text-gray-600 mb-6">You need to be signed in to access your account.</p>
          <Link 
            to="/login"
            className="bg-gradient-to-r from-amber-700 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-800 hover:to-orange-700 transition-all duration-300 inline-flex items-center gap-2"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    await logout();
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-amber-100 mb-8">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-amber-600 to-orange-500 rounded-full flex items-center justify-center">
              {user.google_user_data.picture ? (
                <img 
                  src={user.google_user_data.picture} 
                  alt={user.google_user_data.name || 'User'} 
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <User className="w-10 h-10 text-white" />
              )}
            </div>
            <div className="flex-grow">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                Welcome, {user.google_user_data.given_name || user.google_user_data.name || 'User'}!
              </h1>
              <p className="text-gray-600">Manage your account and view your order history</p>
            </div>
            <div className="text-right">
              <button
                onClick={handleLogout}
                className="text-red-600 hover:text-red-700 font-medium flex items-center gap-2 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Account Information */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-amber-100">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <User className="w-6 h-6 text-amber-600" />
                Account Information
              </h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      {user.google_user_data.name || 'Not provided'}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      {user.google_user_data.given_name || 'Not provided'}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      {user.google_user_data.family_name || 'Not provided'}
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      {user.email}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Verified</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                      {user.google_user_data.email_verified ? '✅ Verified' : '❌ Not verified'}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Member Since</label>
                    <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      {new Date(user.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Order History Placeholder */}
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-amber-100">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <ShoppingBag className="w-6 h-6 text-amber-600" />
                Recent Orders
              </h2>
              <div className="text-center py-12">
                <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-800 mb-2">No Orders Yet</h3>
                <p className="text-gray-600 mb-6">Start shopping to see your order history here</p>
                <Link 
                  to="/products"
                  className="bg-gradient-to-r from-amber-700 to-orange-600 text-white px-6 py-3 rounded-lg hover:from-amber-800 hover:to-orange-700 transition-all duration-300 inline-flex items-center gap-2"
                >
                  Browse Products
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-amber-100">
              <h3 className="text-lg font-bold text-gray-800 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link 
                  to="/products"
                  className="block w-full text-left p-3 rounded-lg hover:bg-amber-50 transition-colors flex items-center gap-3"
                >
                  <ShoppingBag className="w-5 h-5 text-amber-600" />
                  Browse Products
                </Link>
                <Link 
                  to="/cart"
                  className="block w-full text-left p-3 rounded-lg hover:bg-amber-50 transition-colors flex items-center gap-3"
                >
                  <ShoppingBag className="w-5 h-5 text-amber-600" />
                  View Cart
                </Link>
                <Link 
                  to="/contact"
                  className="block w-full text-left p-3 rounded-lg hover:bg-amber-50 transition-colors flex items-center gap-3"
                >
                  <Mail className="w-5 h-5 text-amber-600" />
                  Contact Support
                </Link>
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-600 to-orange-500 rounded-2xl shadow-lg p-6 text-white">
              <div className="flex items-center gap-2 mb-3">
                <Crown className="w-6 h-6" />
                <h3 className="text-lg font-bold">Royal Taste Member</h3>
              </div>
              <p className="text-amber-100 text-sm mb-4">
                Thank you for being a valued customer! Enjoy exclusive access to our authentic Kerala products.
              </p>
              <div className="text-xs text-amber-200">
                Member ID: {user.id.slice(-8).toUpperCase()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
