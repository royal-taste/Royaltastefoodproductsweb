import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { Menu, X, Crown, ShoppingCart, User, LogOut } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';
import { useCart } from '../contexts/CartContext';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const { getTotalItems } = useCart();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Products', path: '/products' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-700 to-orange-600 rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">Royal Taste</h1>
              <p className="text-xs text-gray-500 -mt-1">Food Products</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`font-medium transition-colors relative ${
                  isActive(link.path)
                    ? 'text-amber-700'
                    : 'text-gray-700 hover:text-amber-700'
                }`}
              >
                {link.name}
                {isActive(link.path) && (
                  <div className="absolute -bottom-2 left-0 right-0 h-0.5 bg-amber-700 rounded-full"></div>
                )}
              </Link>
            ))}
            
            {/* Cart Icon */}
            <Link
              to="/cart"
              className={`font-medium transition-colors relative p-2 ${
                isActive('/cart')
                  ? 'text-amber-700'
                  : 'text-gray-700 hover:text-amber-700'
              }`}
            >
              <ShoppingCart className="w-6 h-6" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-700 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </Link>

            {/* User Authentication */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 p-2 text-gray-700 hover:text-amber-700 transition-colors"
                >
                  {user.google_user_data.picture ? (
                    <img 
                      src={user.google_user_data.picture} 
                      alt={user.google_user_data.name || 'User'} 
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <User className="w-6 h-6" />
                  )}
                  <span className="font-medium">
                    {user.google_user_data.given_name || 'Account'}
                  </span>
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                    <Link
                      to="/account"
                      onClick={() => setShowUserMenu(false)}
                      className="block px-4 py-2 text-gray-700 hover:bg-amber-50 hover:text-amber-700 transition-colors"
                    >
                      My Account
                    </Link>
                    <Link
                      to="/admin"
                      onClick={() => setShowUserMenu(false)}
                      className="block px-4 py-2 text-gray-700 hover:bg-amber-50 hover:text-amber-700 transition-colors"
                    >
                      Customer Panel
                    </Link>
                    <button
                      onClick={async () => {
                        setShowUserMenu(false);
                        await logout();
                        window.location.href = '/';
                      }}
                      className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-red-50 hover:text-red-700 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </div>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="bg-gradient-to-r from-amber-700 to-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:from-amber-800 hover:to-orange-700 transition-all duration-300 flex items-center gap-2"
              >
                <User className="w-4 h-4" />
                Sign In
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-amber-700 transition-colors"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`font-medium transition-colors ${
                    isActive(link.path)
                      ? 'text-amber-700'
                      : 'text-gray-700 hover:text-amber-700'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/cart"
                onClick={() => setIsOpen(false)}
                className={`font-medium transition-colors flex items-center gap-2 ${
                  isActive('/cart')
                    ? 'text-amber-700'
                    : 'text-gray-700 hover:text-amber-700'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                Cart {getTotalItems() > 0 && `(${getTotalItems()})`}
              </Link>
              
              {user ? (
                <>
                  <Link
                    to="/account"
                    onClick={() => setIsOpen(false)}
                    className="font-medium text-gray-700 hover:text-amber-700 transition-colors flex items-center gap-2"
                  >
                    <User className="w-5 h-5" />
                    My Account
                  </Link>
                  <Link
                    to="/admin"
                    onClick={() => setIsOpen(false)}
                    className="font-medium text-gray-700 hover:text-amber-700 transition-colors"
                  >
                    Customer Panel
                  </Link>
                  <button
                    onClick={async () => {
                      setIsOpen(false);
                      await logout();
                      window.location.href = '/';
                    }}
                    className="font-medium text-gray-700 hover:text-red-700 transition-colors flex items-center gap-2 text-left"
                  >
                    <LogOut className="w-5 h-5" />
                    Sign Out
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setIsOpen(false)}
                  className="font-medium text-amber-700 hover:text-amber-800 transition-colors flex items-center gap-2"
                >
                  <User className="w-5 h-5" />
                  Sign In
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
